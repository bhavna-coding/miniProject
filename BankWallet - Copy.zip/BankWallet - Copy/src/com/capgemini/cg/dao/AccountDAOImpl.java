package com.capgemini.cg.dao;

import java.util.HashMap;

import com.capgemini.cg.bean.CustomerBean;

public class AccountDAOImpl implements AccountDAOInterface {

	static int accNumber = 100;

	public void storeIntoMap(CustomerBean customer) {

		HashMap<Integer, CustomerBean> hm = new HashMap();
		hm.put(accNumber, customer);
		accNumber++;
		System.out.println("Account Succesfully Created With Account Number: " + accNumber);
		System.out.println(hm.values());
	}

	public void display() {

	}

}
