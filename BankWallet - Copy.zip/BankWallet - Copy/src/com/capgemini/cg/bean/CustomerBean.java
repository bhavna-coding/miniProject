package com.capgemini.cg.bean;

public class CustomerBean {
	private String name;
	private int age;
	private int accbalance = 0;

	public int getAccbalance() {
		return accbalance;
	}

	public void setAccbalance(int accbalance) {
		this.accbalance = accbalance;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

}
