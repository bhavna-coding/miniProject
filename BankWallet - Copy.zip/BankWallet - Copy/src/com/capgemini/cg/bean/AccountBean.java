package com.capgemini.cg.bean;

public class AccountBean {

	private double accNo;
	private int pin;
	private double balance;

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getAccNo() {
		return accNo;
	}

	public void setAccNo(double accNo) {
		this.accNo = accNo;
	}

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

}
