package com.capgemini.cg.service;

import com.capgemini.cg.bean.AccountBean;

import com.capgemini.cg.bean.CustomerBean;

public interface AccountServiceInterface {

	void validateUserName(String name);

	void validateAge(int age);

	void createAccount(CustomerBean customer);

	void showBalance(AccountBean account);

	void transferFund();

	void addMoney(dao d1, int amount);

}
